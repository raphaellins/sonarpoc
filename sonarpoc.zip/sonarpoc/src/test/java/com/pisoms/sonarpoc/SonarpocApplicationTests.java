package com.pisoms.sonarpoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SonarpocApplicationTests {

	@Test
	void contextLoads() {
	}

}
