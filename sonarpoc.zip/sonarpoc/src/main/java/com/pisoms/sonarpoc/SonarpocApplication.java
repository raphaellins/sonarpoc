package com.pisoms.sonarpoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SonarpocApplication {

	public static void main(String[] args) {
		SpringApplication.run(SonarpocApplication.class, args);
	}

}
